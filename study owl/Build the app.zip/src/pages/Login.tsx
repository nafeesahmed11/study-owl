import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { C, Btn, Input } from "../components/ui";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { setError('Please fill in all fields.'); return; }
    setLoading(true);
    setTimeout(() => { navigate('/app/dashboard'); }, 800);
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      <div style={{ width: '100%', maxWidth: '420px' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <img src="/assets/ce79b.svg" alt="Study Owl AI" style={{ height: '44px', marginBottom: '12px' }} />
          <h1 style={{ fontFamily: "'Merriweather', serif", fontSize: '22px', fontWeight: 700, color: C.navy }}>Welcome back</h1>
          <p style={{ fontSize: '14px', color: C.text2, marginTop: '4px' }}>Sign in to your Study Owl AI account</p>
        </div>

        <div style={{ backgroundColor: C.surface, border: `1px solid ${C.border}`, borderRadius: '16px', padding: '32px' }}>
          {error && (
            <div style={{ padding: '10px 14px', backgroundColor: C.errorLight, border: `1px solid ${C.error}`, borderRadius: '8px', marginBottom: '20px', fontSize: '13.5px', color: C.error }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <Input label="Email address" type="email" placeholder="alex@university.edu" value={email} onChange={e => setEmail(e.target.value)} fullWidth />
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: 500, color: C.text }}>Password</label>
                <Link to="/forgot-password" style={{ fontSize: '12px', color: C.indigo }}>Forgot password?</Link>
              </div>
              <input type="password" placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)}
                style={{ width: '100%', padding: '9px 12px', fontSize: '14px', borderRadius: '8px', border: `1.5px solid ${C.border}`, outline: 'none', color: C.text }} />
            </div>

            <Btn type="submit" loading={loading} fullWidth size="lg">Sign In</Btn>
          </form>

          <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '13px', color: C.text2 }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color: C.indigo, fontWeight: 600 }}>Create one</Link>
          </div>
        </div>

        <p style={{ textAlign: 'center', marginTop: '20px', fontSize: '13px', color: C.text3 }}>
          <Link to="/" style={{ color: C.text3 }}>← Back to home</Link>
        </p>
      </div>
    </div>
  );
}
